 window.$ = window.jQuery = require('jquery'); //Library for dom Manipulation


 require('bootstrap-sass'); //Bootstrap for design

 
 // Axios - Ajax Library
 window.axios = require('axios'); 
 window.axios.defaults.headers.common['X-Requested-With'] = 'XMLHttpRequest';


 window.Vue = require('vue'); // JS Framework

 
 require('bootstrap-notify'); //Notify


 require('jquery-form'); //Alternative to Axios


 require('./customComponents.js'); // My components

 //Pie Chart for Vote Result
 require('jquery-flot');
 require('../../../node_modules/jquery-flot/jquery.flot.pie.js');

 
 //Date and Time Management
 window.moment = require('moment');
