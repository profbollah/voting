<template>
<div class="modal-footer">
	<slot></slot>
</div>
</template>
