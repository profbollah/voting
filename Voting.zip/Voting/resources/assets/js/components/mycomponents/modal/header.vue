<template>
<div class="modal-header">
	<button type="button" class="close" data-dismiss="modal">&times;</button>
	<h4><slot></slot></h4>
</div>
</template>
