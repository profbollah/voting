//Global Components
Vue.component('modal', require('./components/mycomponents/modal/modal.vue'))
Vue.component('modal-header', require('./components/mycomponents/modal/header.vue'));
Vue.component('modal-body', require('./components/mycomponents/modal/body.vue'));
Vue.component('modal-footer', require('./components/mycomponents/modal/footer.vue'));

Vue.component('uploader', require('./components/mycomponents/uploader.vue'));
